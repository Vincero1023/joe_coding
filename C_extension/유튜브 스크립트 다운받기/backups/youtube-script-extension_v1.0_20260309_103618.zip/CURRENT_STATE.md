# Current State

Last updated: 2026-03-07

## Goal

This extension currently targets four actions on the active YouTube video page:

1. Open transcript in a new tab
2. Copy transcript to clipboard
3. Download transcript as `.txt`
4. Build a summary prompt and open the selected AI target in temporary mode when supported

## Main Files

- `manifest.json`
- `popup.html`
- `popup.js`
- `popup.css`
- `service_worker.js`
- `transcript.html`
- `transcript.js`
- `transcript.css`
- `offscreen.html`
- `offscreen.js`

## Current Flow

### Transcript fetch

Primary path in `service_worker.js`:

1. `resolveActiveVideoTab()`
2. `fetchTranscriptForVideo(videoId, sourceTabId)`
3. `fetchTranscriptFromCurrentPage(...)`
4. Fallback: `fetchTranscriptViaSourceTab(...)`
5. Final fallback: `fetchTranscriptViaWatchPage(...)`

Important notes:

- The most reliable path right now is the in-page extraction path.
- YouTube direct timedtext fetches can return empty responses depending on current YouTube behavior.
- The source-tab DOM extraction path was strengthened to find transcript-related buttons more aggressively.

### Action behavior

- `open`: saves `lastResult` and opens `transcript.html` in a new tab
- `copy`: copies transcript via page clipboard or offscreen document fallback
- `download`: saves transcript as a text file through `chrome.downloads.download`
- `summarize`: builds a prompt, stores it in `lastResult`, opens the AI page, and tries prompt insertion

## Added Features

### Popup debug panel

Popup now shows a debug panel with:

- last successful transcript path
- ordered attempt list
- last stored error message and code

Debug state is stored in:

- `STORAGE_KEYS.debugState`

### Markdown export

Transcript viewer supports:

- `Download TXT`
- `Download MD`

Markdown export includes:

- title
- video URL
- language and track
- fetched time
- summary prompt when available
- transcript body
- debug metadata when available

### Summary presets

Popup now includes summary preset selection for:

- `default`
- `sermon`
- `lecture`
- `blog`
- `study`

Preset application updates the editable summary template textarea before saving.

## Transcript Formatting

Transcript text is reformatted for readability in:

- `reflowTranscriptForReading()`
- `splitIntoReadableParagraphs()`
- `splitIntoSentences()`

Current paragraph logic uses:

- sentence boundaries
- paragraph sentence count
- paragraph character length
- topic-shift starters such as `however`, `for example`, `but`, `however`, `하지만`, `예를 들어`
- question / prompt endings

## Known Recovery Steps

If behavior looks wrong after edits:

1. Open `chrome://extensions`
2. Remove the unpacked extension completely
3. Reload this exact folder again as unpacked
4. Verify popup build label and behavior

## Quick Sanity Checks

Run from this folder:

```powershell
node --check service_worker.js
node --check popup.js
node --check transcript.js
node --check content_shortcuts.js
node --check offscreen.js
```

## Known Constraints

- YouTube transcript availability varies by video
- Some videos expose no usable caption data to direct fetch
- AI site auto-insertion is best-effort and depends on current site DOM

## If It Breaks Again

Start from these checkpoints:

1. Does the popup status show a concrete error message?
2. Does `open` create `transcript.html` in a new tab?
3. What does the popup debug panel show for the latest fetch path and attempts?
4. Does `fetchTranscriptFromCurrentPage()` fail first?
5. Does `fetchTranscriptViaSourceTab()` still find transcript UI?
6. Is the failure only in `summarize` model selection or prompt insertion?
