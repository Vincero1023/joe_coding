const DEFAULT_SETTINGS = {
  preferredLanguage: "",
  gptSiteUrl: "https://chatgpt.com/",
  aiModel: "chatgpt",
  autoSubmit: true,
  chatgptTemporaryChat: true,
  summaryTemplate: "",
  summaryPreset: "default"
};

const BUILD_LABEL = "1.4.12-direct-fetch";

const SUMMARY_PRESETS = {
  default:
    "Analyze the following YouTube transcript and organize it in a 2-layer output.\n\n[Layer 1: Structure For Understanding]\n- One-sentence core claim of the video\n- Organize into 5-10 thought blocks\n- Compress each block into 2-3 sentences\n- Keep the logical flow explicit\n\n[Layer 2: Reusable Material Extraction]\nExtract and present as a table:\n- Quotes / notable lines\n- Statistics / data / experiment results\n- Cases / examples\n- References / books / papers\nFor each item include:\n- Short summary\n- Where it can be reused (sermon/lecture/blog/etc)\n- Category\n- 3-5 hashtags\n\nFocus on thought-structure decomposition and material extraction, not generic summarization.\n\nTitle: {{TITLE}}\nURL: {{URL}}\n\nTranscript:\n{{TEXT}}",
  sermon:
    "Read the following YouTube transcript and turn it into sermon-ready material.\n\nOutput:\n- Core biblical or spiritual thesis in one sentence\n- 3-5 sermon movements with clear progression\n- Key illustrations, stories, and memorable lines\n- Practical application points for listeners\n- Closing challenge or response prompt\n\nKeep the tone faithful to the source, but restructure for preaching clarity.\n\nTitle: {{TITLE}}\nURL: {{URL}}\n\nTranscript:\n{{TEXT}}",
  lecture:
    "Analyze the following transcript as lecture material.\n\nOutput:\n- Main thesis\n- Section-by-section outline\n- Definitions, key concepts, and frameworks\n- Important examples or supporting evidence\n- Potential discussion questions\n- Concise review summary for students\n\nPrefer clarity, structure, and educational usefulness over general summarization.\n\nTitle: {{TITLE}}\nURL: {{URL}}\n\nTranscript:\n{{TEXT}}",
  blog:
    "Transform the following transcript into blog-ready material.\n\nOutput:\n- Proposed article title options\n- Strong opening hook\n- 4-7 section outline with section summaries\n- Quotable lines worth preserving\n- Practical takeaways for readers\n- Suggested closing paragraph idea\n\nKeep the structure scannable and publication-friendly.\n\nTitle: {{TITLE}}\nURL: {{URL}}\n\nTranscript:\n{{TEXT}}",
  study:
    "Turn the following transcript into study notes.\n\nOutput:\n- Main argument in one sentence\n- Hierarchical outline\n- Key facts, claims, and evidence\n- Important terms and short definitions\n- Questions worth reviewing later\n- Brief recap section for revision\n\nOptimize for learning, review, and note-taking.\n\nTitle: {{TITLE}}\nURL: {{URL}}\n\nTranscript:\n{{TEXT}}"
};

const elements = {
  status: document.getElementById("status"),
  customAiUrl: document.getElementById("customAiUrl"),
  language: document.getElementById("language"),
  autoSubmit: document.getElementById("autoSubmit"),
  chatgptTemporaryChat: document.getElementById("chatgptTemporaryChat"),
  summaryPreset: document.getElementById("summaryPreset"),
  applyPreset: document.getElementById("applyPreset"),
  summaryTemplate: document.getElementById("summaryTemplate"),
  modelButtons: Array.from(document.querySelectorAll(".model-btn")),
  saveButton: document.getElementById("saveSettings"),
  actionButtons: Array.from(document.querySelectorAll("[data-action]")),
  buildInfo: document.getElementById("buildInfo"),
  debugInfo: document.getElementById("debugInfo")
};

let selectedModel = DEFAULT_SETTINGS.aiModel;

initialize().catch((error) => setStatus(error.message, true));

async function initialize() {
  const response = await sendMessage({ type: "get-settings" });
  if (!response.ok) {
    throw new Error(await formatUiError(response, "Failed to load settings."));
  }

  const settings = { ...DEFAULT_SETTINGS, ...(response.settings || {}) };
  selectedModel = String(settings.aiModel || DEFAULT_SETTINGS.aiModel);
  elements.customAiUrl.value = settings.gptSiteUrl || DEFAULT_SETTINGS.gptSiteUrl;
  elements.language.value = settings.preferredLanguage || "";
  elements.autoSubmit.checked = Boolean(settings.autoSubmit);
  elements.chatgptTemporaryChat.checked = Boolean(settings.chatgptTemporaryChat);
  elements.summaryPreset.value = SUMMARY_PRESETS[String(settings.summaryPreset || "default")]
    ? String(settings.summaryPreset || "default")
    : "default";
  elements.summaryTemplate.value = settings.summaryTemplate || "";
  renderModelSelection();
  await renderDebugInfo();

  const manifest = chrome.runtime.getManifest();
  elements.buildInfo.textContent = `Version ${manifest.version} (${BUILD_LABEL})`;

  elements.saveButton.addEventListener("click", onSaveSettings);
  elements.modelButtons.forEach((button) => {
    button.addEventListener("click", () => {
      selectedModel = button.dataset.model || "chatgpt";
      renderModelSelection();
    });
  });
  elements.applyPreset.addEventListener("click", applySelectedPreset);
  elements.actionButtons.forEach((button) => {
    button.addEventListener("click", () => runAction(button.dataset.action));
  });
}

function collectSettingsPayload() {
  return {
    aiModel: selectedModel,
    gptSiteUrl: elements.customAiUrl.value.trim() || DEFAULT_SETTINGS.gptSiteUrl,
    preferredLanguage: elements.language.value.trim(),
    autoSubmit: elements.autoSubmit.checked,
    chatgptTemporaryChat: elements.chatgptTemporaryChat.checked,
    summaryPreset: elements.summaryPreset.value,
    summaryTemplate: elements.summaryTemplate.value.trim()
  };
}

function renderModelSelection() {
  elements.modelButtons.forEach((button) => {
    button.classList.toggle("active", button.dataset.model === selectedModel);
  });
  elements.customAiUrl.disabled = selectedModel !== "custom";
}

async function onSaveSettings() {
  toggleBusy(true);
  try {
    const response = await sendMessage({
      type: "save-settings",
      settings: collectSettingsPayload()
    });

    if (!response.ok) {
      throw new Error(await formatUiError(response, "Failed to save settings."));
    }

    setStatus("Settings saved.");
  } catch (error) {
    setStatus(error.message, true);
  } finally {
    toggleBusy(false);
  }
}

async function runAction(action) {
  toggleBusy(true);
  setStatus("Working...");
  try {
    // Use latest UI settings immediately.
    const saveResponse = await sendMessage({
      type: "save-settings",
      settings: collectSettingsPayload()
    });
    if (!saveResponse.ok) {
      throw new Error(await formatUiError(saveResponse, "Failed to apply settings."));
    }

    const response = await sendMessage({
      type: "run-action",
      action
    });

    if (!response.ok) {
      throw new Error(await formatUiError(response, "Action failed."));
    }

    setStatus(response.result || "Done.");
    await renderDebugInfo();
  } catch (error) {
    setStatus(error.message, true);
    await renderDebugInfo();
  } finally {
    toggleBusy(false);
  }
}

function applySelectedPreset() {
  const preset = String(elements.summaryPreset.value || "default");
  elements.summaryTemplate.value = SUMMARY_PRESETS[preset] || SUMMARY_PRESETS.default;
  setStatus(`Applied preset: ${preset}.`);
}

function toggleBusy(isBusy) {
  elements.actionButtons.forEach((button) => {
    button.disabled = isBusy;
  });
  elements.modelButtons.forEach((button) => {
    button.disabled = isBusy;
  });
  elements.saveButton.disabled = isBusy;
}

function setStatus(message, isError = false) {
  elements.status.textContent = message;
  elements.status.classList.toggle("error", Boolean(isError));
}

function sendMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      if (chrome.runtime.lastError) {
        resolve({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      resolve(response || { ok: false, error: "Empty response." });
    });
  });
}

async function formatUiError(response, fallback) {
  const message = String(response?.error || "").trim();
  if (message) {
    return message;
  }

  const code = String(response?.errorCode || "").trim();
  if (code) {
    const latest = await sendMessage({ type: "get-error-log", errorCode: code });
    const logMessage = String(latest?.log?.message || "").trim();
    if (logMessage) {
      return `Error. ${logMessage} (${code})`;
    }
    return `Error. Code: ${code}`;
  }
  return fallback;
}

async function renderDebugInfo() {
  const [debugResponse, errorResponse] = await Promise.all([
    sendMessage({ type: "get-debug-state" }),
    sendMessage({ type: "get-latest-error-log" })
  ]);

  const debugState = debugResponse?.settings || debugResponse?.data || {};
  const lastFetch = debugState?.lastFetch;
  const lastError = errorResponse?.log || debugState?.lastError || null;

  const lines = [];

  if (lastFetch) {
    lines.push(`Last fetch path: ${lastFetch.successPath || "-"}`);
    lines.push(`Build: ${lastFetch.buildId || "-"}`);
    if (Array.isArray(lastFetch.attempts) && lastFetch.attempts.length) {
      lines.push("Attempts:");
      for (const item of lastFetch.attempts) {
        lines.push(`- ${item.step}: ${item.ok ? "OK" : "FAIL"} | ${item.message || ""}`);
      }
    }
  } else {
    lines.push("Last fetch path: -");
  }

  if (lastError) {
    lines.push("");
    lines.push(`Last error: ${lastError.message || "-"}`);
    if (lastError.code) {
      lines.push(`Error code: ${lastError.code}`);
    }
  }

  elements.debugInfo.textContent = lines.join("\n").trim() || "No debug data yet.";
}
